"""PyMotion Lite SDK 的内部实现包。

用户程序必须通过 ``import pymotion as pm`` 和 ``pm.lite`` 使用 SDK。本包内的
传输、协议、解析和固件兼容模块均属于私有实现，因此不会从这里重新导出。
"""

__version__ = "1.0.1"

__all__: list[str] = []
